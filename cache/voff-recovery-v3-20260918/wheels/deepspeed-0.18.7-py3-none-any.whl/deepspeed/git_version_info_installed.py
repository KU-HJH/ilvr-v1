version='0.18.7'
git_hash='unknown'
git_branch='unknown'
installed_ops={'async_io': False, 'fused_adam': False, 'cpu_adam': False, 'cpu_adagrad': False, 'cpu_lion': False, 'dc': False, 'evoformer_attn': False, 'fp_quantizer': False, 'fused_lamb': False, 'fused_lion': False, 'gds': False, 'transformer_inference': False, 'inference_core_ops': False, 'cutlass_ops': False, 'quantizer': False, 'ragged_device_ops': False, 'ragged_ops': False, 'random_ltd': False, 'sparse_attn': False, 'spatial_inference': False, 'transformer': False, 'stochastic_transformer': False, 'utils': False}
accelerator_name='cuda'
torch_info={'version': '2.7', 'bf16_support': True, 'cuda_version': '12.8', 'nccl_version': '2.26', 'hip_version': '0.0'}
